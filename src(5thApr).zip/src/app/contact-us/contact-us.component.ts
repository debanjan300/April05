import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
    var loggedUserName=localStorage.getItem("loggedUserName");
    var loggedRole=localStorage.getItem("role");
    // alert(loggedUserName)
    if(loggedUserName==null)
    {
      alert("You have not logged in!!")
    this.router.navigateByUrl('/(col3:Login)');
    }
    else
    { 
      alert(loggedRole);
      if(loggedRole=="User"){

          this.router.navigateByUrl('/(col1:contact)');
      }
    else{
      alert("You are an Admin. You are not allowed in this page!!");
      this.router.navigateByUrl('/(col3:home)');
    }
    }
  }

}
