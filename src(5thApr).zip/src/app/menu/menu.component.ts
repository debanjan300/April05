import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import { LoginComponent } from '../login/login.component';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class MenuComponent implements OnInit {
  status:string;
  constructor(private cd:ChangeDetectorRef) {
    this.status='Login';
    
   }

  ngOnInit(): void {
   this.refresh();
  }

  // ngOnChanges(){
  //  this.refresh();
  // }

  refresh()
  {
    this.cd.detectChanges();
    var loggedUserName=localStorage.getItem("loggedUserName");
    // alert(loggedUserName)
    if(loggedUserName==null)
      this.status="Login";
    else
      this.status="Logout";
      // alert(this.status)
    // var userName=this.lc.loginForm.controls.userName.value;
    // if(userName!=null)
    //     this.status="Logout";
  }
}
